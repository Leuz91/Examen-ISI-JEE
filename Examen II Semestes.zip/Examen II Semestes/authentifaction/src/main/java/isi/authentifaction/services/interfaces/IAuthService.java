package isi.authentifaction.services.interfaces;

import isi.authentifaction.dto.requests.AuthRequest;
import isi.authentifaction.dto.requests.RefreshRequest;
import isi.authentifaction.dto.requests.RegisterRequest;
import isi.authentifaction.dto.responses.TokenResponse;

public interface IAuthService {
    TokenResponse register(RegisterRequest req);
    TokenResponse login(AuthRequest req);
    TokenResponse refresh(RefreshRequest req);
}