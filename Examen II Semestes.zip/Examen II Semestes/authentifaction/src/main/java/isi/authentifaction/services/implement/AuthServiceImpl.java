package isi.authentifaction.services.implement;

import isi.authentifaction.model.RefreshToken;
import isi.authentifaction.model.User;
import isi.authentifaction.dto.requests.AuthRequest;
import isi.authentifaction.dto.requests.RefreshRequest;
import isi.authentifaction.dto.requests.RegisterRequest;
import isi.authentifaction.dto.responses.TokenResponse;
import isi.authentifaction.repository.RefreshTokenRepository;
import isi.authentifaction.repository.UserRepository;
import isi.authentifaction.security.JwtService;
import isi.authentifaction.services.interfaces.IAuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements IAuthService {

    private final AuthenticationManager authManager;
    private final UserRepository users;
    private final RefreshTokenRepository refreshTokens;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    @Value("${security.jwt.access-expiration-minutes:15}")
    private long accessMinutes;

    @Value("${security.jwt.refresh-expiration-days:7}")
    private long refreshDays;

    @Transactional
    @Override
    public TokenResponse register(RegisterRequest req) {
        if (users.existsByUsername(req.username()) || users.existsByEmail(req.email())) {
            // FR
            throw new IllegalArgumentException("Nom d'utilisateur ou e-mail déjà utilisé.");
        }

        User u = users.save(User.builder()
                .username(req.username())
                .email(req.email())
                .password(encoder.encode(req.password()))
                .roles(Set.of("USER"))
                .enabled(true)
                .build());

        return issueTokensFor(u); // connexion automatique après inscription
    }

    @Transactional
    @Override
    public TokenResponse login(AuthRequest req) {
        authManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.username(), req.password())
        );
        User u = users.findByUsername(req.username()).orElseThrow();
        return issueTokensFor(u);
    }

    @Transactional
    @Override
    public TokenResponse refresh(RefreshRequest req) {
        RefreshToken rt = refreshTokens.findByToken(req.refreshToken())
                // FR
                .orElseThrow(() -> new BadCredentialsException("Jeton de rafraîchissement invalide."));
        if (rt.isRevoked() || rt.getExpiresAt().isBefore(Instant.now()))
            // FR
            throw new BadCredentialsException("Jeton de rafraîchissement expiré ou révoqué.");

        rt.setRevoked(true);
        refreshTokens.save(rt);

        return issueTokensFor(rt.getUser());
    }

    private TokenResponse issueTokensFor(User u) {
        Instant accessExp = Instant.now().plus(Duration.ofMinutes(accessMinutes));
        String access = jwt.generateAccessToken(u, Duration.ofMinutes(accessMinutes));

        String rawRefresh = UUID.randomUUID().toString().replace("-", "");
        Instant refreshExp = Instant.now().plus(Duration.ofDays(refreshDays));
        refreshTokens.save(RefreshToken.builder()
                .token(rawRefresh)
                .user(u)
                .expiresAt(refreshExp)
                .revoked(false)
                .createdAt(Instant.now())
                .build());

        return new TokenResponse(access, accessExp, rawRefresh, refreshExp, "Bearer");
    }
}
