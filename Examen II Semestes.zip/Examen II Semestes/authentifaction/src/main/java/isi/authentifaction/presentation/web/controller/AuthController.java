package isi.authentifaction.presentation.web.controller;

import isi.authentifaction.dto.requests.AuthRequest;
import isi.authentifaction.dto.requests.RefreshRequest;
import isi.authentifaction.dto.requests.RegisterRequest;
import isi.authentifaction.dto.responses.TokenResponse;
import isi.authentifaction.model.User;
import isi.authentifaction.repository.UserRepository;
import isi.authentifaction.services.interfaces.IAuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping
@RequiredArgsConstructor
public class AuthController {

    private final IAuthService auth;
    private final UserRepository users;

    @PostMapping("/register")
    public ResponseEntity<TokenResponse> register(@RequestBody RegisterRequest req) {
        return ResponseEntity.status(201).body(auth.register(req));
    }

    @PostMapping("/auth/token")
    public ResponseEntity<TokenResponse> token(@RequestBody AuthRequest req) {
        return ResponseEntity.ok(auth.login(req));
    }

    @PostMapping("/auth/refresh-token")
    public ResponseEntity<TokenResponse> refresh(@RequestBody RefreshRequest req) {
        return ResponseEntity.ok(auth.refresh(req));
    }

    @GetMapping("/auth/me")
    public ResponseEntity<?> me(@AuthenticationPrincipal UserDetails principal) {
        if (principal == null) return ResponseEntity.status(401).build();
        User u = users.findByUsername(principal.getUsername()).orElse(null);
        if (u == null) return ResponseEntity.status(404).body(Map.of("message","Utilisateur introuvable"));
        return ResponseEntity.ok(Map.of(
                "username", u.getUsername(),
                "email", u.getEmail(),
                "roles", u.getRoles()
        ));
    }
}
