package isi.authentifaction.mappers;


import isi.authentifaction.model.User;
import isi.authentifaction.dto.responses.MeResponse;
import org.mapstruct.Mapper;

@Mapper (componentModel = "spring")
public interface UserMapper {
    MeResponse toMeResponse(User user);
}
