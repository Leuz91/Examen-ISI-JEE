package isi.authentifaction;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;

@TestConfiguration
class TestAuthBeans {

    // AuthManager ultra-minimal pour laisser démarrer le contexte
    @Bean
    AuthenticationManager testAuthenticationManager() {
        return authentication -> authentication;
    }
}
