package com.example.demo.dto;

public record ClassDTO(Long id, String className, String description, Long sectorId) {

}
