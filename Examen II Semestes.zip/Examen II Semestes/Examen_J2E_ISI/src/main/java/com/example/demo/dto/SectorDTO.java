package com.example.demo.dto;

public record SectorDTO(Long id, String name) {

}
