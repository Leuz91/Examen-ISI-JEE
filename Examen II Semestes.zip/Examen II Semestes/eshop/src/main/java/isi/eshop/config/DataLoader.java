package isi.eshop.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import isi.eshop.domain.*;
import isi.eshop.repository.*;

@Configuration
@Profile("dev") //
public class DataLoader {

    @Bean CommandLineRunner init(CategoryRepository catRepo, ProductRepository prodRepo, UserRepository userRepo){
        return args -> {
            var cat1 = ensureCategory(catRepo, "Electronics");
            var cat2 = ensureCategory(catRepo, "Books");

            ensureProduct(prodRepo, "Laptop Pro", 1499.0, cat1);
            ensureProduct(prodRepo, "USB-C Hub", 39.9, cat1);
            ensureProduct(prodRepo, "Clean Architecture", 29.0, cat2);

            ensureUser(userRepo, "Awa", "Diop", "awa@eshop.sn");
            ensureUser(userRepo, "Moussa", "Ndiaye", "moussa@eshop.sn");
        };
    }

    private Category ensureCategory(CategoryRepository repo, String name){
        return repo.findByNameIgnoreCase(name).orElseGet(() ->
                repo.save(Category.builder().name(name).build())
        );
    }

    private Product ensureProduct(ProductRepository repo, String name, double price, Category cat){
        return repo.findByNameIgnoreCase(name).orElseGet(() ->
                repo.save(Product.builder().name(name).price(price).category(cat).build())
        );
    }

    private User ensureUser(UserRepository repo, String first, String last, String email){
        return repo.findByEmail(email).orElseGet(() ->
                repo.save(User.builder().firstName(first).lastName(last).email(email).build())
        );
    }
}
