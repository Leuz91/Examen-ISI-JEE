package isi.eshop.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import isi.eshop.domain.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    Optional<Category> findByNameIgnoreCase(String name);
}
